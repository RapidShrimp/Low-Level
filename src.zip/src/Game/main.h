#pragma once


int main();
void InitialiseEngine();
void UpdateLoop();
void Shutdown();
GameInstance* m_Instance;
