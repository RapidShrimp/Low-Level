#pragma once
#include "Object.h"
#include "SFML/Graphics.hpp"
#include "GameScene.h"

class GameInstance {
public:
	
	GameInstance();
	~GameInstance();
	//Singleton
	static GameInstance* m_GameInstance;
	static GameInstance* GetGameInstance();


	bool m_GameExit = false;
protected:



	sf::RenderWindow m_GameWindow;
	shared_ptr<GameScene> m_CurrentScene;
	shared_ptr<GameScene> m_NextScene;

private:

public:
	void Init();
	void Update();
	void FixedUpdate(float deltaTime);
	void Render();
	void CloseGame();
};