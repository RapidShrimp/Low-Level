#pragma once
#include "SFML/Graphics.hpp"
#include "GameObject.h"
#include "string"
#include "Engine/Core/Events/Event.h"
#include <SFML/Graphics/RenderWindow.hpp>

class Object;
class Transform;

class GameScene : public Object{

public:
	GameScene();
	~GameScene();


protected:
	std::string m_SceneName = "Unassigned";
	std::vector<Object*> SceneObjects;

private:

	void RegisterSpawnedObject(Object* RegisterObject, bool Activate);

public:
	GameObject* SpawnObject(GameObject* Spawnable, SinStr::Transform SpawnTransform, bool StartActive = true, std::string DisplayName = "Unassigned");
	GameObject* SpawnObject(GameObject* Spawnable, Math::Vector2 SpawnLocation, bool StartActive = true, std::string DisplayName = "Unassigned");

	void RenderScene(sf::RenderWindow& Renderer);
	void Update();
	virtual void OnLoadScene();
	virtual void UnloadScene();
};