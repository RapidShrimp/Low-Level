#pragma once
class ActionMapping 
{
public:
	sf::Keyboard::Key KeyEvent = sf::Keyboard::Key::Unknown;
	bool IsTriggered = false;
};
