#pragma once
#include "Maths.h"

namespace SinStr {

	namespace Physics {




	}
}